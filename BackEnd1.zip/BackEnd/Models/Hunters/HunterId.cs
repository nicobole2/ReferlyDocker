namespace Referly.Models.Hunters;

public partial class HunterId
{
    public string Id{ get; set;}

    public HunterId() {
        Id??="";
    }
}
