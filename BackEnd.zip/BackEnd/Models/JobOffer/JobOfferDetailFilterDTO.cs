namespace Referly.Models.JobOffer;

public class JobOfferDetailFilterDTO
{
    public int JobId { get; set; }
}